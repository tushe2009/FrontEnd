<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
 
    <script >
 
 
    
     
     
     
     
 var memory = +prompt('Memory');
var color=prompt('Цвет');
 
         var memory1={64:300, 128:500};
         console.log(memory1[memory]);
     var color2=['gold','black','silver'];
        var price;
               var error;
    var picture;
 if (memory1.hasOwnProperty(memory) ) {
   price=memory1[memory];
 }  
    else {
   error = 'Нет такой памяти';
 }
        
        
        
    if(color=="black"){
          picture="black1.png";
    }
          if(color=="gold"){
          picture="gold.png";
    }
            if(color=="silver"){
          picture="silver.png";
    }
        else if(color==""){
            picture="default.png";
        }
        else{
            error="Нет цвета нет";
        }
            
             
            

 
       
      
    


 if (error) {
   document.write('<h1 style="color: red">' + error + '</h1>');
 } else {
   document.write('<h1>PRICE: ' + price+ '$</h1><br><img src=img/'+picture+'>');
 }
  
    </script>
<h1></h1>
</body>
</html>